import torch

def squash_mask(self, mask):
    return torch.sigmoid(self.pmask_slope * mask)

def sparsify(self, mask):   #此时mask的形状为(B,1,H,W)
    mask = mask.clone()  # 避免修改原始张量
    xbar = torch.mean(mask, dim=(2, 3))  # 计算整个mask的均值  代表目前掩码的稀疏度 xbar的形状为(B,1)
    r = self.sparsity / xbar  # 稀疏度除以均值    要求的稀疏度除以目前的稀疏度 r的形状也是(B,1) 广播机制
    beta = (1 - self.sparsity) / (1 - xbar)   #beta 的形状也是(B,1)
    le = (r <= 1).float()  # 如果r<=1 说明要求的稀疏度比目前的稀疏度小 说明现在采样采多了 如果r>1 说明目前采样采少了
    for i in range(mask.shape[0]):
        mask[i] = le[i] * mask[i] * r[i] + (1 - le[i]) * (1 - (1 - mask[i]) * beta[i])
    return mask
        # 如果r<=1 即采样采多了 le =1   则return   mask * r 整个稀疏度变为要求稀疏度
        # 如果 r>1 即说明采样采少了 le =0 则return   1-（1-mask）* beta 整个稀疏度变为要求稀疏度

def sigmoid_beta(self, mask):
    random_uniform = torch.empty(*self.image_dims).uniform_(0, 1).cuda()
        # torch.empty 为创建一个具有self.image_dims 的空张量 uniform(0,1)在空张量中填充随机值，这些值在[0,1]之间

    random_uniform = random_uniform.unsqueeze(0).unsqueeze(0).repeat(mask.shape[0], 1, 1, 1)
        #random_uniform 的形状为(B,1,H,W)

    return torch.sigmoid(self.sample_slope * (mask - random_uniform))
        # 从mask中减去随机数张量

