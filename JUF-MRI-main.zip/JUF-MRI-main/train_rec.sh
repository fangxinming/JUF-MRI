python train.py -opt configs/only_reconstruction.yaml
